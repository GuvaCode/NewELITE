this.name = "griff_spawn_sparks"; 
this.author = "Thargoid"; 
this.copyright = "� 2008 the Oolite team."; 
this.description = "Break-up of griff wreckage into a tiny spark cluster"; 
this.version = "1.0"; 

this.shipSpawned = function () 
{
	// Put here your code for when a ship is created
      this.ship.velocity = new Vector3D.random(50.0 + Math.random( ) * 50.0)

};

this.shipDied = function()
	{
	if(!this.ship || (player.ship.isValid && this.ship.position.distanceTo(player.ship.position) > 50000)) return; // exit the script if the explosion happens far from the player
	this.tinysparkCount = (Math.ceil(Math.random() * 8) + 2); // between 2-10 tiny spark fragments
	this.ship.spawn("griff_arcelite_spinspark", this.tinysparkCount); // spawn the tiny spark fragments
	}
