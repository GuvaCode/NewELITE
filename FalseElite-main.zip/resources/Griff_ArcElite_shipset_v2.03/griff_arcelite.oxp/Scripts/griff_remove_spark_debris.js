this.name           = "griff_remove_spark_debris"
this.author         = "Griff"
this.licence        = "Creative Commons Attribution-Noncommercial-Share Alike 3.0 Unported License"
this.description    = "Randomly disperses and removes griff spark items";
this.version        = "1.0"

this.shipSpawned = function () 
{
	// Put here your code for when a ship is created
       this.ship.velocity = new Vector3D.random(50.0 + Math.random( ) * 50.0)

};

this.shipRemove = function()  // Remove the object silently
	{
	this.ship.remove()
	}