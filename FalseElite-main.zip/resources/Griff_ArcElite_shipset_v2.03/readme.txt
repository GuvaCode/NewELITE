GriffArcelite Shipset_v2.03
---------------------------
Replacement shipset for Oolite based on the 8-bit and Acorn Archimedes versions of Elite.


griff_arcelite.oxp
------------------
Contains the following Archimedes Elite ships:
asteroid, coriolis-station, dodecahedron-station, icosahedron-station, adder*, anaconda*, asp mk2*, boa mk2*, 
bushmaster, caiman, cobra mk1*, cobra mk3*, copperhead, ferdelance*, gecko, krait, mamba, moccasin*, moray*, 
python*, racer*, shuttle, sidewinder, thargoid, tharglet, transporter, urutu, viper, worm

Also includes these alternate ship versions from the 8-bit Elites: anaconda*, asp*, Boa*, cobra_Mk1*, constrictor


griff_arcelite_alternative_color_stations_asteroids.oxp
-------------------------------------------------------
Adds alternative color scheme versions for asteroids and stations



griff_arcelite_elite2_ships.oxp
-------------------------------
Contains the following Elite 2 ships, shaded in a similar style to the Arcelite ships:
bug*, cat (aka cougar), delta, drake*, gnat, griffin mk1*, griffin mk2*
This oxp can be removed if not wanted.



griff_arcelite_eliteA_ships.oxp
-------------------------------
Contains the following Elite 'A' ships, shaded in a similar style to the Arcelite ships:
bushmaster*, chameleon*, ghavial*, iguana*, monitor*, ophidian*, salamander*, shuttle
This oxp can be removed if not wanted.


* denotes player flyable craft

start_ship_is_arcelite_cobra3.oxp
---------------------------------
Optional OXP. Having this installed starts you off in an ArcElite CobraIII rather than the Default Oolite cobra III, the diference is purely cosmetic, ship stats between the Oolite Cobra III and the ArcElite Cobra III are identical


Griff 01 April 2013

Bug reports and balanced ship prices/stats for the extra ships are welcome!! :)

Original Ship meshes found at http://mackayj.doosh.net/arcships.html  (still viewable through the 'wayback machine' website!)

OXP thread: http://www.aegidian.org/bb/viewtopic.php?t=5102

OXP Wiki page: http://wiki.alioth.net/index.php/Griff_ArcElite


Update History
v2.0 - original release - 01 April 2013
v2.01 - fixed 'bug' & 'gnat' models z axis - they were flying backwards in-game! - 02 April 2013
v2.02 - updated cargo hold size and prices to match http://elite.acornarcade.com/elahint.htm
v2.03 - fixed Salamandar player version using the incorrect ship model